'''
Uncomment the line "input()" if you want to keep python window open after the tests are complete  
'''
def main(INIfn, version):
    import os,sys        
    py_ver = sys.version
    if py_ver.startswith('3.8'):
        tools_path = 'TOOLs(py3.8)'
    elif py_ver.startswith('3.9'):
        tools_path = 'TOOLs(py3.9)'
    elif py_ver.startswith('3.11'):
        tools_path = 'TOOLs(py3.11)'
    else:
        print ('Python 3.8 or 3.9 is needed for DMView')
        quit() 

    sys.path.insert(0,os.path.abspath(tools_path))
    from DMView_main import DMView_main 
    DMView_main(INIfn,version,tools_path)
    #input("\nPress any key to end the program")
    
if __name__ == '__main__':
    import os, sys
    if len(sys.argv)>1:   
       temp = sys.argv[1]
       temp = temp.strip()
       if len(temp)>1:
          rootfn, ext = os.path.splitext(temp)
          if len(ext)<1:
             INIfn = rootfn+'.ini'
          else:
             INIfn = temp             
       version = '3.4beta'
       main(INIfn, version)
    
